import { DynamoDBClient } from "@aws-sdk/client-dynamodb";

import {
  DynamoDBDocumentClient,
  PutCommand,
  ScanCommand,
  DeleteCommand,
  UpdateCommand,
  GetCommand
} from "@aws-sdk/lib-dynamodb";

import {
  SNSClient,
  PublishCommand
} from "@aws-sdk/client-sns";

import CryptoJS from "crypto-js";


// ========================================
// CLIENTS
// ========================================

const client = new DynamoDBClient({});

const docClient =
  DynamoDBDocumentClient.from(client);

const sns = new SNSClient({
  region: "ap-south-1"
});


// ========================================
// CONFIG
// ========================================

const TABLE_NAME = "NotesTable";

const APPROVED_USERS_TABLE =
  "ApprovedUsers";

const SNS_TOPIC_ARN =
  "arn:aws:sns:ap-south-1:748715687700:UnauthorizedAccessAlerts";

const SECRET_KEY =
  process.env.NOTES_SECRET;


// ========================================
// CORS
// ========================================

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "*"
};


// ========================================
// MAIN HANDLER
// ========================================

export const handler = async (event) => {

  try {

    console.log(
      "========== LAMBDA START =========="
    );

    console.log(
      "FULL EVENT:",
      JSON.stringify(event)
    );

    // ========================================
    // USER CLAIMS
    // ========================================

    const claims =
      event.requestContext.authorizer.jwt.claims;

    const email =
      claims.email.toLowerCase().trim();

    const tenantId =
      claims.sub;

    console.log("EMAIL:", email);

    console.log("TENANT ID:", tenantId);


    // ========================================
    // CHECK APPROVED USER
    // ========================================

    const approvedUser =
      await docClient.send(

      new GetCommand({

        TableName:
          APPROVED_USERS_TABLE,

        Key: {
          email: email
        }
      })
    );

    console.log(
      "APPROVED USER:",
      approvedUser
    );


    // ========================================
    // UNAUTHORIZED USER
    // ========================================

    if (!approvedUser.Item) {

      console.log(`
=====================================
SECURITY ALERT
=====================================

UNAUTHORIZED_USER_DETECTED

Email:
${email}

IP Address:
${event.requestContext.http.sourceIp}

Time:
${new Date().toISOString()}

=====================================
`);

      // ====================================
      // SNS ALERT
      // ====================================

      await sns.send(

        new PublishCommand({

          TopicArn:
            SNS_TOPIC_ARN,

          Subject:
            "🚨 Unauthorized Access Attempt",

          Message: `
Unauthorized login attempt detected.

Email:
${email}

IP Address:
${event.requestContext.http.sourceIp}

Time:
${new Date().toISOString()}
          `
        })
      );

      return {

        statusCode: 403,

        headers: corsHeaders,

        body: JSON.stringify({

          message:
            "Access denied. User not approved."
        })
      };
    }


    // ========================================
    // REQUEST INFO
    // ========================================

    const method =
      event.requestContext.http.method;

    const path =
      event.rawPath;

    console.log("METHOD:", method);

    console.log("PATH:", path);


    // ========================================
    // OPTIONS
    // ========================================

    if (method === "OPTIONS") {

      return {

        statusCode: 200,

        headers: corsHeaders,

        body: JSON.stringify({
          message: "CORS OK"
        })
      };
    }


    // ========================================
    // CREATE NOTE
    // ========================================

    if (
      method === "POST" &&
      path === "/notes"
    ) {

      const body =
        JSON.parse(event.body);

      const encryptedContent =
        CryptoJS.AES.encrypt(
          body.content,
          SECRET_KEY
        ).toString();

      const note = {

        tenantId,

        noteId:
          Date.now().toString(),

        content:
          encryptedContent,

        createdAt:
          new Date().toISOString()
      };

      await docClient.send(

        new PutCommand({

          TableName:
            TABLE_NAME,

          Item: note
        })
      );

      return {

        statusCode: 200,

        headers: corsHeaders,

        body: JSON.stringify({

          message:
            "Note created successfully"
        })
      };
    }


    // ========================================
    // GET NOTES
    // ========================================

    if (
      method === "GET" &&
      path === "/notes"
    ) {

      const result =
        await docClient.send(

        new ScanCommand({

          TableName:
            TABLE_NAME
        })
      );

      const userNotes =
        result.Items.filter(

          note =>
            note.tenantId === tenantId
        );

      const decryptedNotes =
        userNotes.map(note => {

          const bytes =
            CryptoJS.AES.decrypt(
              note.content,
              SECRET_KEY
            );

          const decryptedContent =
            bytes.toString(
              CryptoJS.enc.Utf8
            );

          return {

            ...note,

            content:
              decryptedContent
          };
        });

      return {

        statusCode: 200,

        headers: corsHeaders,

        body: JSON.stringify(
          decryptedNotes
        )
      };
    }


    // ========================================
    // UPDATE NOTE
    // ========================================

    if (
      method === "PUT" &&
      path.startsWith("/notes/")
    ) {

      const noteId =
        event.pathParameters.noteId;

      const body =
        JSON.parse(event.body);

      const encryptedContent =
        CryptoJS.AES.encrypt(
          body.content,
          SECRET_KEY
        ).toString();

      await docClient.send(

        new UpdateCommand({

          TableName:
            TABLE_NAME,

          Key: {
            tenantId,
            noteId
          },

          UpdateExpression:
            "set content = :c",

          ExpressionAttributeValues: {
            ":c":
              encryptedContent
          }
        })
      );

      return {

        statusCode: 200,

        headers: corsHeaders,

        body: JSON.stringify({

          message:
            "Note updated successfully"
        })
      };
    }


    // ========================================
    // DELETE NOTE
    // ========================================

    if (
      method === "DELETE" &&
      path.startsWith("/notes/")
    ) {

      const noteId =
        event.pathParameters.noteId;

      await docClient.send(

        new DeleteCommand({

          TableName:
            TABLE_NAME,

          Key: {
            tenantId,
            noteId
          }
        })
      );

      return {

        statusCode: 200,

        headers: corsHeaders,

        body: JSON.stringify({

          message:
            "Note deleted successfully"
        })
      };
    }


    // ========================================
    // INVALID ROUTE
    // ========================================

    return {

      statusCode: 400,

      headers: corsHeaders,

      body: JSON.stringify({

        message:
          "Invalid request"
      })
    };

  } catch (err) {

    console.error(
      "========== ERROR =========="
    );

    console.error(err);

    return {

      statusCode: 500,

      headers: corsHeaders,

      body: JSON.stringify({

        message:
          "Internal server error",

        error:
          err.message
      })
    };
  }
};